package com.app.model;


import lombok.Data;

@Data
public class Employee {

    private Integer empno;
    private String empname;
    private String empaddrs;
    private Double salary;
    private Double grossSalary;
    private Double netSalary;




}
